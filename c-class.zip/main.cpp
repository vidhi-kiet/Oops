/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<cstring>
using namespace std;

class cat
{
    private:
    string name;
    string breed;
    int age;
    
    public:
    void set_name(string nm)
    {
        name=nm;
    }
    
    string get_name()
    {
        return name;
    }
    
     void set_breed(string br)
    {
        breed=br;
    }
    
    string get_breed()
    {
        return breed;
    }
    
    
     void set_age(int a)
    {
        age=a;
    }
    
    int get_age()
    {
        return age;
    }
    
    void printinfo()
    {
     cout<<name<<","<<breed<<","<<age;
    }

    
    
    
 };


int main()
{
    int age;
    string name,breed;
    cat c1;
    c1.set_name("beacka");
    c1.set_breed("puff");
    c1.set_age(2);
    
    cout<<c1.get_name()<<'\n';
    cout<<c1.get_breed()<<'\n';
    cout<<c1.get_age()<<'\n';
    c1.printinfo();
    return 0;
}

