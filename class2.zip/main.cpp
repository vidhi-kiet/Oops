/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


class student
{
    
    string name;
    int age;
    char gender;
    
    public:
    void setname(string n)
    {
        name=n;
    }
    string getname()
    {
        return name;
    }
    
    void setage(int a)
    {
        age=a;
    }
    int getage()
    {
        return age;
    }
    void setgender(char g)
    {
        gender=g;
    }
    char getgender()
    {
        return gender;
    }
    
    
    
    
};

int main()
{
    string name;
    int age;
    char gender;
    cout<<"enter: ";
    cin>>name>>age>>gender;
     student a;
     a.setname(name);
     a.setage(age);
     a.setgender(gender);
     cout<<a.getname()<<endl;
     cout<<a.getage()<<endl;
     cout<<a.getgender()<<endl;
    return 0;
}